import { useState, useEffect } from "react";

const rutina = {
  "Lunes – Pecho + Tríceps": [
    { nombre: "Press banca barra", series: 5 },
    { nombre: "Press inclinado mancuernas", series: 4 },
    { nombre: "Press máquina convergente", series: 3 },
    { nombre: "Aperturas polea", series: 3 },
    { nombre: "Fondos lastrados", series: 4 },
  ],
  "Martes – Espalda + Bíceps": [
    { nombre: "Dominadas lastradas", series: 5 },
    { nombre: "Remo barra", series: 4 },
    { nombre: "Jalón neutro", series: 3 },
    { nombre: "Pullover polea", series: 3 },
    { nombre: "Curl barra", series: 4 },
  ],
  "Miércoles – Pierna (Cuádriceps)": [
    { nombre: "Sentadilla", series: 5 },
    { nombre: "Prensa", series: 4 },
    { nombre: "Hack squat", series: 3 },
    { nombre: "Extensión cuádriceps", series: 3 },
  ],
  "Jueves – Hombro + Brazos": [
    { nombre: "Press mancuernas", series: 4 },
    { nombre: "Elevaciones laterales", series: 6 },
    { nombre: "Pájaros", series: 4 },
    { nombre: "Curl predicador", series: 4 },
    { nombre: "Press cerrado", series: 4 },
  ],
  "Viernes – Espalda + Pecho": [
    { nombre: "Jalón amplio", series: 4 },
    { nombre: "Remo bajo", series: 4 },
    { nombre: "Press inclinado máquina", series: 4 },
    { nombre: "Cruces polea", series: 4 },
  ],
  "Sábado – Pierna (Posterior)": [
    { nombre: "Peso muerto rumano", series: 4 },
    { nombre: "Curl femoral", series: 4 },
    { nombre: "Hip thrust", series: 4 },
    { nombre: "Zancadas caminando", series: 4 },
  ],
};

export default function App() {
  const hoy = new Date().toISOString().split("T")[0];
  const [fecha] = useState(hoy);
  const [registro, setRegistro] = useState({});
  const [timer, setTimer] = useState(0);

  useEffect(() => {
    const data = localStorage.getItem("registroEntreno");
    if (data) setRegistro(JSON.parse(data));
  }, []);

  useEffect(() => {
    localStorage.setItem("registroEntreno", JSON.stringify(registro));
  }, [registro]);

  useEffect(() => {
    const i = setInterval(() => setTimer((t) => t + 1), 1000);
    return () => clearInterval(i);
  }, []);

  const actualizar = (dia, ejercicio, serie, campo, valor) => {
    setRegistro((prev) => ({
      ...prev,
      [fecha]: {
        ...prev[fecha],
        [dia]: {
          ...prev[fecha]?.[dia],
          [ejercicio]: {
            ...prev[fecha]?.[dia]?.[ejercicio],
            [serie]: {
              ...prev[fecha]?.[dia]?.[ejercicio]?.[serie],
              [campo]: valor,
            },
          },
        },
      },
    }));
  };

  const copiarUltimo = () => {
    const fechas = Object.keys(registro).sort();
    if (fechas.length < 2) return;
    setRegistro((prev) => ({
      ...prev,
      [fecha]: registro[fechas[fechas.length - 2]],
    }));
  };

  const tiempo = `${Math.floor(timer / 60)}:${("0" + (timer % 60)).slice(-2)}`;

  return (
    <div style={{ background: "#000", color: "#fff", padding: 16 }}>
      <h1>Modo Competición</h1>
      <p>Fecha: {fecha}</p>
      <p>⏱ Tiempo: {tiempo}</p>
      <button onClick={copiarUltimo}>Copiar último entreno</button>

      {Object.entries(rutina).map(([dia, ejercicios]) => (
        <div key={dia}>
          <h2>{dia}</h2>
          {ejercicios.map((ej) => (
            <div key={ej.nombre}>
              <strong>{ej.nombre}</strong>
              {Array.from({ length: ej.series }).map((_, i) => (
                <div key={i}>
                  <input
                    type="number"
                    placeholder="Kg"
                    onChange={(e) =>
                      actualizar(dia, ej.nombre, i + 1, "kg", e.target.value)
                    }
                  />
                  <input
                    type="number"
                    placeholder="Reps"
                    onChange={(e) =>
                      actualizar(dia, ej.nombre, i + 1, "reps", e.target.value)
                    }
                  />
                  <input
                    type="number"
                    placeholder="RPE"
                    onChange={(e) =>
                      actualizar(dia, ej.nombre, i + 1, "rpe", e.target.value)
                    }
                  />
                </div>
              ))}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}